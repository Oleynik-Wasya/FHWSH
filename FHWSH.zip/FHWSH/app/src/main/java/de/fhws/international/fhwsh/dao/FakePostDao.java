package de.fhws.international.fhwsh.dao;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import de.fhws.international.fhwsh.models.Post;

public class FakePostDao {
    // static variable single_instance of type Singleton
    private static FakePostDao single_instance = null;

    // variable of type String
    public Map<Long, Post> db;

    // private constructor restricted to this class itself
    @RequiresApi(api = Build.VERSION_CODES.O)
    private FakePostDao() {
        db = new HashMap<>();
        db.put(1l, new Post(1, "FHWS International office", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum hendrerit elit at suscipit imperdiet. Integer aliquet dui et ultrices consectetur. Phasellus nisl augue, tristique sed faucibus quis, laoreet ut orci. Praesent laoreet ligula est, nec dictum eros vehicula vel. Duis quis fringilla erat, eget rhoncus velit. Fusce at posuere eros. Vivamus ut ligula fringilla, auctor libero nec, accumsan justo. Phasellus ipsum ante, gravida eu feugiat maximus, rutrum nec dolor.", LocalDate.now()));
        db.put(2l, new Post(2, "New Photos from Uni", "Aliquam erat volutpat. Etiam a elit arcu. Mauris euismod, orci vel imperdiet tincidunt, lorem leo ultricies dui, quis fringilla orci sem ac nisi. Donec ac congue leo, quis mattis leo. Cras egestas, purus nec maximus faucibus, velit sapien maximus neque, eget venenatis tellus orci quis ex. Aliquam vel ex vitae leo tincidunt malesuada. Fusce sit amet erat laoreet, semper orci sed, vestibulum leo. Proin vitae eleifend nulla, in eleifend tellus. Aenean eleifend magna vel felis auctor suscipit. Pellentesque placerat fermentum felis nec luctus. Suspendisse consequat consequat justo, et semper nisi cursus eu. Pellentesque sollicitudin non nisi sed tempor. Duis a massa tincidunt magna ultrices venenatis. Nulla sit amet dui sed ex gravida eleifend.", LocalDate.now()));
        db.put(3l, new Post(3, "Necessary information about the Exam!", "Phasellus faucibus risus ullamcorper est accumsan elementum. Quisque id tempus metus. Nam velit mauris, vestibulum dignissim eleifend vitae, volutpat sed nibh. Nulla cursus tincidunt metus, sed sollicitudin nisl bibendum vitae. In vitae egestas elit. Etiam elit lacus, accumsan ut purus id, iaculis sagittis nibh. Nunc et vehicula odio. Donec vitae elementum massa. Aenean efficitur turpis id rutrum aliquam. Praesent in vestibulum justo. Curabitur tincidunt, orci quis euismod pellentesque, massa est dapibus felis, finibus gravida magna dui sit amet lacus. Nulla eget accumsan erat, sit amet sollicitudin metus.", LocalDate.now()));
    }

    // static method to create instance of Singleton class
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static FakePostDao getInstance() {
        if (single_instance == null)
            single_instance = new FakePostDao();

        return single_instance;
    }

    public void addNewPost(Post post) {
        db.put(post.getId(), post);
    }

    public void deletePost(long id) {
        db.remove(id);
    }
}
