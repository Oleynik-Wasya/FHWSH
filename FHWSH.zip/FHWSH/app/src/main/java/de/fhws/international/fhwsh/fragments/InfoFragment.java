package de.fhws.international.fhwsh.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.time.LocalDate;

import de.fhws.international.fhwsh.R;
import de.fhws.international.fhwsh.dao.FakePostDao;
import de.fhws.international.fhwsh.models.Post;

@RequiresApi(api = Build.VERSION_CODES.O)
public class InfoFragment extends Fragment {

    FakePostDao fakePostDao = FakePostDao.getInstance();

    @Nullable
    @Override

    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable final Bundle savedInstanceState) {
        SharedPreferences sharedpreferences = getActivity().getSharedPreferences(getString(R.string.refName),
                Context.MODE_PRIVATE);
        boolean admin = sharedpreferences.getString("role", "").contains("grp_fiw_fiwis_teststaff");

        final View view = inflater.inflate(R.layout.fragment_info, container, false);

        // Get the widgets reference from XML layout
        LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.listInfo);
        RecyclerView.Adapter adapter = new Re


        if (admin) {
            Button btnTag = new Button(view.getContext());
            btnTag.setLayoutParams(view.getLayoutParams());
            btnTag.setText("Add new post");

            btnTag.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fakePostDao.addNewPost(new Post(4l, "Added Post", "I have just added a new post :)", LocalDate.now()));
                    onCreateView(inflater, container, savedInstanceState);
                }
            });

            linearLayout.addView(btnTag, 0);
            container.invalidate();
        }


        for (Post value : fakePostDao.db.values()) {
            // Create a TextView programmatically.
            TextView title = new TextView(view.getContext());
            TextView text = new TextView(view.getContext());
            TextView date = new TextView(view.getContext());


            View line = new View(view.getContext());
            ViewGroup.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 5);
            line.setLayoutParams(layoutParams);
            line.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

            // Apply the layout parameters to TextView widget
            title.setLayoutParams(linearLayout.getLayoutParams());
            text.setLayoutParams(linearLayout.getLayoutParams());

            // Set text to display in TextView
            title.setText(value.getTitle());
            title.setTypeface(null, Typeface.BOLD);
            title.setPadding(10, 10, 10, 0);
            title.setTextSize(view.getResources().getDimension(R.dimen.postTitleSize) / view.getResources().getDisplayMetrics().density);
            text.setText(value.getInfo());
            text.setPadding(10, 0, 10, 30);
            text.setTextSize(view.getResources().getDimension(R.dimen.postTextSize) / view.getResources().getDisplayMetrics().density);
            text.setTextColor(Color.parseColor("#b3b3b3"));
            date.setText(value.getDate().toString());
            date.setPadding(10, 0, 0, 0);
            date.setTypeface(null, Typeface.ITALIC);
            // Add newly created TextView to parent view group (RelativeLayout)
            linearLayout.addView(title, 1);
            linearLayout.addView(date, 2);
            linearLayout.addView(text, 3);

            if (admin) {
                Button btnDel = new Button(view.getContext());
                btnDel.setLayoutParams(view.getLayoutParams());
                btnDel.setText("Delete post");

                linearLayout.addView(btnDel, 4);

                Button btnEdit = new Button(view.getContext());
                btnEdit.setLayoutParams(view.getLayoutParams());
                btnEdit.setText("Edit post");

                linearLayout.addView(btnEdit, 5);
            }
            linearLayout.addView(line, 6);
        }

        return view;
    }

}
